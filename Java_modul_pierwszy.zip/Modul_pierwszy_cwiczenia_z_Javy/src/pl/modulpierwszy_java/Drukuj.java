package pl.modulpierwszy_java;

public class Drukuj {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Wiedza to potega !");
		System.out.println("Wiedza\nto\npotega !");
		System.out.println(" ====================\n|Wiedza to potega ! |\n ====================");
	}
}
